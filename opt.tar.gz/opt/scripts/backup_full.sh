#!/bin/bash

# Ayuda
if [[ $1 == "-help" ]]; then
    echo "Uso: backup_full.sh <origen> <destino>"
    exit 0
fi

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename $ORIGEN)

# Validar origen y destino
if [[ ! -d $ORIGEN ]]; then
    echo "El origen no existe"
    exit 1
fi

if [[ ! -d $DESTINO ]]; then
    echo "El destino no existe"
    exit 1
fi

# Hacer el backup
tar -czf $DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz $ORIGEN
echo "Backup completado"
